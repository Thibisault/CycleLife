# PWA Cycles 29‑6‑29‑6‑9 (Corps & Esprit)

PWA **HTML/CSS/JS vanilla** sans dépendances. Boucle infinie :
**Travail 29:00 → Sport 6:00 → Travail 29:00 → Sport 6:00 → Pause 9:00**

## Fonctionnalités
- Durées **éditables** (mm:ss), **persistées** (localStorage)
- **Sous‑exercices** durant Sport (nom, durée, ordre, auto‑remplir)
- **Sons** (Web Audio), **Vibrations**, **Notifications**, **Wake Lock**
- **PWA installable**, **offline** (Service Worker), compatible **GitHub Pages**

## Déploiement
1. Pousse ces fichiers sur un dépôt.
2. Active **GitHub Pages** (branche `main`, racine).
3. Ouvre l’URL en HTTPS, installe la PWA.

## Utilisation
- Démarrer / Pause / Arrêter / Précédent / Suivant
- Réglages : durées, sous‑exercices (auto‑remplir ex: 6 × 00:50), volume/muet, notifications.
